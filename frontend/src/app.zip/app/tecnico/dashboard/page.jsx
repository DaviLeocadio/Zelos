import Card from "@/components/CardVirgem/Card";
import './dash.css'

export default function Meus_chamados() {

  return (
    <>
      <div className="d-flex align-items-center flex-wrap justify-content-center h-100 w-100 mt-5 gap-2">
        <Card />
      </div>
    </>
  );
}